const express = require('express');
const Contact = require('../models/Contact');
const authenticate = require('../middleware/auth');
const router = express.Router();

router.use(authenticate);

router.post('/', async (req, res) => {
  const { name, email, phone } = req.body;

  try {
    const contact = new Contact({
      userId: req.user.userId,
      name,
      email,
      phone,
    });

    await contact.save();
    res.status(201).json({ message: 'Contact created', contact });
  } catch (error) {
    res.status(500).json({ message: 'Error creating contact', error });
  }
});

router.get('/', async (req, res) => {
  try {
    const contacts = await Contact.find({ userId: req.user.userId });
    res.json({ contacts });
  } catch (error) {
    res.status(500).json({ message: 'Error fetching contacts', error });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const contact = await Contact.findOne({ _id: req.params.id, userId: req.user.userId });
    if (!contact) {
      return res.status(404).json({ message: 'Contact not found' });
    }
    res.json({ contact });
  } catch (error) {
    res.status(500).json({ message: 'Error fetching contact', error });
  }
});

router.put('/:id', async (req, res) => {
  const { name, email, phone } = req.body;

  try {
    const contact = await Contact.findOneAndUpdate(
      { _id: req.params.id, userId: req.user.userId },
      { name, email, phone },
      { new: true }
    );

    if (!contact) {
      return res.status(404).json({ message: 'Contact not found' });
    }

    res.json({ message: 'Contact updated', contact });
  } catch (error) {
    res.status(500).json({ message: 'Error updating contact', error });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const contact = await Contact.findOneAndDelete({ _id: req.params.id, userId: req.user.userId });

    if (!contact) {
      return res.status(404).json({ message: 'Contact not found' });
    }

    res.json({ message: 'Contact deleted' });
  } catch (error) {
    res.status(500).json({ message: 'Error deleting contact', error });
  }
});

module.exports = router;
